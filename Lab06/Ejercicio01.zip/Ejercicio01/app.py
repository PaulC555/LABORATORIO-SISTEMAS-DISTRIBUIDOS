from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

estudiantes = [
    {
        "id": 1,
        "nombre": "Paul Contreras",
        "edad": 21,
        "carrera": "Ingeniería de Sistemas"
    }
]

@app.route('/estudiantes', methods=['GET'])
def listar_estudiantes():
    return jsonify(estudiantes), 200

@app.route('/estudiantes', methods=['POST'])
def registrar_estudiante():
    nuevo_estudiante = request.json
    estudiantes.append(nuevo_estudiante)

    return jsonify({
        "mensaje": "Estudiante registrado correctamente",
        "estudiante": nuevo_estudiante
    }), 201

@app.route('/estudiantes/<int:id>', methods=['PUT'])
def actualizar_estudiante(id):
    for estudiante in estudiantes:
        if estudiante["id"] == id:
            datos = request.json
            estudiante["nombre"] = datos.get("nombre", estudiante["nombre"])
            estudiante["edad"] = datos.get("edad", estudiante["edad"])
            estudiante["carrera"] = datos.get("carrera", estudiante["carrera"])

            return jsonify({
                "mensaje": "Estudiante actualizado correctamente",
                "estudiante": estudiante
            }), 200

    return jsonify({"mensaje": "Estudiante no encontrado"}), 404

@app.route('/estudiantes/<int:id>', methods=['DELETE'])
def eliminar_estudiante(id):
    for estudiante in estudiantes:
        if estudiante["id"] == id:
            estudiantes.remove(estudiante)

            return jsonify({
                "mensaje": "Estudiante eliminado correctamente"
            }), 200

    return jsonify({"mensaje": "Estudiante no encontrado"}), 404

if __name__ == '__main__':
    app.run(debug=True)